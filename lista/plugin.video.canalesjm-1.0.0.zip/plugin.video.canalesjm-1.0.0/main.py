import sys
import xbmcplugin
import xbmcgui
import urllib.request

addon_handle = int(sys.argv[1])
url_m3u = "https://jmalorod.github.io/lista/listajm.m3u"
xbmcplugin.setContent(addon_handle, 'videos')

def parse_m3u(url):
    try:
        response = urllib.request.urlopen(url)
        m3u_content = response.read().decode("utf-8")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al acceder a la lista M3U: {str(e)}")
        return []

    channels = []
    channel_info = ""
    for line in m3u_content.splitlines():
        if line.startswith("#EXTINF"):
            channel_info = line.split(",")[1].strip()
        elif line.startswith("plugin://"):  # Cambiado para aceptar enlaces acestream
            channels.append((channel_info, line.strip()))
    return channels

channels = parse_m3u(url_m3u)

for name, stream_url in channels:
    list_item = xbmcgui.ListItem(label=name)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=list_item, isFolder=False)

xbmcplugin.endOfDirectory(addon_handle)
