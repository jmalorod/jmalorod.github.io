import xbmcplugin
import xbmcgui
import xbmcaddon
import urllib.request
import sys

addon_handle = int(sys.argv[1])
url_m3u = "https://jmalorod.github.io/lista/listajm.m3u"
xbmcplugin.setContent(addon_handle, 'videos')

def parse_m3u(url):
    response = urllib.request.urlopen(url)
    m3u_content = response.read().decode("utf-8")
    channels = []
    for line in m3u_content.splitlines():
        if line.startswith("#EXTINF"):
            channel_info = line.split(",")[1].strip()
        elif line.startswith("acestream://"):
            channels.append((channel_info, line.strip()))
    return channels

channels = parse_m3u(url_m3u)

for name, stream_url in channels:
    list_item = xbmcgui.ListItem(label=name)
    # Crear una URL interna personalizada para cada canal
    custom_url = '{}?url={}'.format(sys.argv[0], stream_url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=custom_url, listitem=list_item, isFolder=False)

xbmcplugin.endOfDirectory(addon_handle)

# Detectar si se ha invocado con una URL personalizada
if 'url' in sys.argv[2]:
    import urllib.parse as urlparse
    params = dict(urlparse.parse_qsl(sys.argv[2][1:]))  # Leer parámetros de la URL
    stream_url = params.get('url')
    if stream_url and stream_url.startswith("acestream://"):
        horus_url = 'plugin://script.module.horus/?url=' + stream_url
        # Invocar a Horus usando xbmc.executebuiltin para ejecutar el plugin de Horus
        xbmc.executebuiltin('RunPlugin({})'.format(horus_url))

